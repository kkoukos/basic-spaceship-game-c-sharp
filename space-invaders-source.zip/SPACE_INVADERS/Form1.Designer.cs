﻿namespace SPACE_INVADERS
{
    partial class SPACE_INVADERS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SPACE_INVADERS));
            this.player = new System.Windows.Forms.PictureBox();
            this.render = new System.Windows.Forms.Timer(this.components);
            this.enemy = new System.Windows.Forms.PictureBox();
            this.playing = new System.Windows.Forms.Timer(this.components);
            this.second = new System.Windows.Forms.Timer(this.components);
            this.left = new System.Windows.Forms.PictureBox();
            this.right = new System.Windows.Forms.PictureBox();
            this.h1 = new System.Windows.Forms.PictureBox();
            this.h2 = new System.Windows.Forms.PictureBox();
            this.h3 = new System.Windows.Forms.PictureBox();
            this.expl = new System.Windows.Forms.PictureBox();
            this.scoreB = new System.Windows.Forms.TextBox();
            this.startbut = new System.Windows.Forms.PictureBox();
            this.HSB = new System.Windows.Forms.TextBox();
            this.end = new System.Windows.Forms.PictureBox();
            this.namein = new System.Windows.Forms.TextBox();
            this.menu = new System.Windows.Forms.PictureBox();
            this.mainp = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.left)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.h3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.expl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startbut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.end)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainp)).BeginInit();
            this.SuspendLayout();
            // 
            // player
            // 
            this.player.BackColor = System.Drawing.Color.Transparent;
            this.player.ErrorImage = ((System.Drawing.Image)(resources.GetObject("player.ErrorImage")));
            this.player.Image = ((System.Drawing.Image)(resources.GetObject("player.Image")));
            this.player.InitialImage = ((System.Drawing.Image)(resources.GetObject("player.InitialImage")));
            this.player.Location = new System.Drawing.Point(215, 630);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(50, 60);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 0;
            this.player.TabStop = false;
            this.player.WaitOnLoad = true;
            this.player.Click += new System.EventHandler(this.SPACE_INVADERS_Click);
            // 
            // render
            // 
            this.render.Enabled = true;
            this.render.Interval = 16;
            this.render.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // enemy
            // 
            this.enemy.BackColor = System.Drawing.Color.Transparent;
            this.enemy.Image = ((System.Drawing.Image)(resources.GetObject("enemy.Image")));
            this.enemy.Location = new System.Drawing.Point(215, 50);
            this.enemy.Name = "enemy";
            this.enemy.Size = new System.Drawing.Size(50, 60);
            this.enemy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy.TabIndex = 1;
            this.enemy.TabStop = false;
            // 
            // playing
            // 
            this.playing.Enabled = true;
            this.playing.Interval = 50;
            this.playing.Tick += new System.EventHandler(this.playing_Tick);
            // 
            // second
            // 
            this.second.Enabled = true;
            this.second.Interval = 1000;
            this.second.Tick += new System.EventHandler(this.second_Tick);
            // 
            // left
            // 
            this.left.BackColor = System.Drawing.Color.Transparent;
            this.left.Image = ((System.Drawing.Image)(resources.GetObject("left.Image")));
            this.left.Location = new System.Drawing.Point(-1, 0);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(154, 88);
            this.left.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.left.TabIndex = 2;
            this.left.TabStop = false;
            // 
            // right
            // 
            this.right.BackColor = System.Drawing.Color.Transparent;
            this.right.Image = ((System.Drawing.Image)(resources.GetObject("right.Image")));
            this.right.Location = new System.Drawing.Point(331, 0);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(154, 88);
            this.right.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.right.TabIndex = 3;
            this.right.TabStop = false;
            // 
            // h1
            // 
            this.h1.BackColor = System.Drawing.Color.Gray;
            this.h1.Image = ((System.Drawing.Image)(resources.GetObject("h1.Image")));
            this.h1.Location = new System.Drawing.Point(12, 0);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(28, 28);
            this.h1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.h1.TabIndex = 4;
            this.h1.TabStop = false;
            // 
            // h2
            // 
            this.h2.BackColor = System.Drawing.Color.Gray;
            this.h2.Image = ((System.Drawing.Image)(resources.GetObject("h2.Image")));
            this.h2.Location = new System.Drawing.Point(46, 0);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(28, 28);
            this.h2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.h2.TabIndex = 5;
            this.h2.TabStop = false;
            // 
            // h3
            // 
            this.h3.BackColor = System.Drawing.Color.Gray;
            this.h3.Image = ((System.Drawing.Image)(resources.GetObject("h3.Image")));
            this.h3.Location = new System.Drawing.Point(80, 0);
            this.h3.Name = "h3";
            this.h3.Size = new System.Drawing.Size(28, 28);
            this.h3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.h3.TabIndex = 6;
            this.h3.TabStop = false;
            // 
            // expl
            // 
            this.expl.BackColor = System.Drawing.Color.Transparent;
            this.expl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.expl.Location = new System.Drawing.Point(215, 116);
            this.expl.Name = "expl";
            this.expl.Size = new System.Drawing.Size(50, 50);
            this.expl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.expl.TabIndex = 7;
            this.expl.TabStop = false;
            // 
            // scoreB
            // 
            this.scoreB.BackColor = System.Drawing.Color.Gray;
            this.scoreB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.scoreB.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.scoreB.Location = new System.Drawing.Point(372, 8);
            this.scoreB.Name = "scoreB";
            this.scoreB.ReadOnly = true;
            this.scoreB.Size = new System.Drawing.Size(100, 13);
            this.scoreB.TabIndex = 8;
            // 
            // startbut
            // 
            this.startbut.BackColor = System.Drawing.Color.Transparent;
            this.startbut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("startbut.BackgroundImage")));
            this.startbut.Image = ((System.Drawing.Image)(resources.GetObject("startbut.Image")));
            this.startbut.Location = new System.Drawing.Point(131, 243);
            this.startbut.Name = "startbut";
            this.startbut.Size = new System.Drawing.Size(228, 94);
            this.startbut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.startbut.TabIndex = 9;
            this.startbut.TabStop = false;
            this.startbut.MouseDown += new System.Windows.Forms.MouseEventHandler(this.startbut_MouseDown);
            this.startbut.MouseLeave += new System.EventHandler(this.startbut_MouseLeave);
            this.startbut.MouseHover += new System.EventHandler(this.startbut_MouseHover);
            this.startbut.MouseUp += new System.Windows.Forms.MouseEventHandler(this.startbut_MouseUp);
            // 
            // HSB
            // 
            this.HSB.BackColor = System.Drawing.Color.Black;
            this.HSB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HSB.ForeColor = System.Drawing.Color.White;
            this.HSB.ImeMode = System.Windows.Forms.ImeMode.On;
            this.HSB.Location = new System.Drawing.Point(131, 380);
            this.HSB.Multiline = true;
            this.HSB.Name = "HSB";
            this.HSB.ReadOnly = true;
            this.HSB.Size = new System.Drawing.Size(228, 166);
            this.HSB.TabIndex = 10;
            this.HSB.Text = "---HIGHSCORES---";
            this.HSB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // end
            // 
            this.end.Image = ((System.Drawing.Image)(resources.GetObject("end.Image")));
            this.end.Location = new System.Drawing.Point(199, 369);
            this.end.Name = "end";
            this.end.Size = new System.Drawing.Size(90, 40);
            this.end.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.end.TabIndex = 11;
            this.end.TabStop = false;
            this.end.Click += new System.EventHandler(this.end_Click);
            this.end.MouseDown += new System.Windows.Forms.MouseEventHandler(this.end_MouseDown);
            this.end.MouseLeave += new System.EventHandler(this.end_MouseLeave);
            this.end.MouseHover += new System.EventHandler(this.end_MouseHover);
            // 
            // namein
            // 
            this.namein.BackColor = System.Drawing.Color.Gray;
            this.namein.Location = new System.Drawing.Point(189, 343);
            this.namein.Name = "namein";
            this.namein.Size = new System.Drawing.Size(110, 20);
            this.namein.TabIndex = 12;
            this.namein.Text = "ENTER NAME";
            this.namein.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.namein.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // menu
            // 
            this.menu.Image = ((System.Drawing.Image)(resources.GetObject("menu.Image")));
            this.menu.Location = new System.Drawing.Point(-1, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(484, 800);
            this.menu.TabIndex = 13;
            this.menu.TabStop = false;
            this.menu.Click += new System.EventHandler(this.menu_Click);
            // 
            // mainp
            // 
            this.mainp.BackColor = System.Drawing.Color.Transparent;
            this.mainp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mainp.BackgroundImage")));
            this.mainp.Image = ((System.Drawing.Image)(resources.GetObject("mainp.Image")));
            this.mainp.Location = new System.Drawing.Point(110, 50);
            this.mainp.Name = "mainp";
            this.mainp.Size = new System.Drawing.Size(279, 179);
            this.mainp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mainp.TabIndex = 14;
            this.mainp.TabStop = false;
            // 
            // SPACE_INVADERS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(484, 761);
            this.Controls.Add(this.mainp);
            this.Controls.Add(this.HSB);
            this.Controls.Add(this.end);
            this.Controls.Add(this.namein);
            this.Controls.Add(this.startbut);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.scoreB);
            this.Controls.Add(this.expl);
            this.Controls.Add(this.enemy);
            this.Controls.Add(this.h3);
            this.Controls.Add(this.h2);
            this.Controls.Add(this.h1);
            this.Controls.Add(this.right);
            this.Controls.Add(this.left);
            this.Controls.Add(this.player);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SPACE_INVADERS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Space Invaders";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SPACE_INVADERS_FormClosing);
            this.Load += new System.EventHandler(this.SPACE_INVADERS_Load);
            this.Click += new System.EventHandler(this.SPACE_INVADERS_Click);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SPACE_INVADERS_KeyPress);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SPACE_INVADERS_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.left)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.h3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.expl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startbut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.end)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.Timer render;
        private System.Windows.Forms.PictureBox enemy;
        private System.Windows.Forms.Timer playing;
        private System.Windows.Forms.Timer second;
        private System.Windows.Forms.PictureBox left;
        private System.Windows.Forms.PictureBox right;
        private System.Windows.Forms.PictureBox h1;
        private System.Windows.Forms.PictureBox h2;
        private System.Windows.Forms.PictureBox h3;
        private System.Windows.Forms.PictureBox expl;
        private System.Windows.Forms.TextBox scoreB;
        private System.Windows.Forms.PictureBox startbut;
        private System.Windows.Forms.TextBox HSB;
        private System.Windows.Forms.PictureBox end;
        private System.Windows.Forms.TextBox namein;
        private System.Windows.Forms.PictureBox menu;
        private System.Windows.Forms.PictureBox mainp;
    }
}

