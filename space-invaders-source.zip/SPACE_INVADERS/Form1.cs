﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Media;
using System.Threading;


namespace SPACE_INVADERS
{


    public partial class SPACE_INVADERS : Form
    
    {
        List<PictureBox> bulletse = new List<PictureBox>();
        List<PictureBox> bulletsf = new List<PictureBox>();
        List<String> names = new List<String>();
        List<int> scores = new List<int>();


       
        
        
        Bitmap bulle;
        Bitmap bullf;
        SoundPlayer shoot;
        
        Random rnd = new Random();
        int move = 0;
        bool animating =false;
        int moves=4;
        int speed = 10;
        bool dmg = false;
        bool dmg2 = false;
        bool startb = false;
        string path;
        int health = 3;
        int immune = 2;
        int immune2 = 2;
        int score = 0;
        bool hover = false;
        int random = 5;
        String[] separator = { "," };




        public void bullet(int c)
        {
            
            PictureBox bull = new PictureBox();
            bull.SizeMode = PictureBoxSizeMode.StretchImage;
            bull.ClientSize = new Size(10,30);
            Controls.Add(bull);

            shoot.Play();

            
            if (c == 0) {
               bull.Image = (Image) bulle;
                
                bulletse.Add(bull);
                bull.Location = new Point(enemy.Location.X - 25, enemy.Location.Y + 40);
               
            }
            else
            {
                bull.Image = (Image)bullf;
                bulletsf.Add(bull);
                bull.Location = new Point(player.Location.X + 20, player.Location.Y - 40);
            }

            bull.BackColor = Color.Transparent;

        }

        public void start()
        {
            startb = true;
            animating = true;
            left.Location = new Point(-1, 0);
            right.Location = new Point(331, 0);
            h1.Location = new Point(12, 0);
            h2.Location = new Point(46, 0);
            h3.Location = new Point(80, 0);
            enemy.Location = new Point(215,50);
            player.Location = new Point(215, 630);
            h3.Image = new Bitmap(Path.Combine(path, @"SPRITES\\heart.png"));
            h2.Image = new Bitmap(Path.Combine(path, @"SPRITES\\heart.png"));
            h1.Image = new Bitmap(Path.Combine(path, @"SPRITES\\heart.png"));
            menu.Location = new Point(-700, 0);
            scoreB.Location = new Point(372, 8);
            namein.Location = new Point(-100, -100);
            mainp.Location = new Point(-310, -50);

        }

        public void menustart()
        {
            mainp.Location = new Point(110, 50);
            hover = false;
            end.Location = new Point(-200, -200);
            scoreB.Location = new Point(-200, -200);
            left.Location = new Point(-1, 0);
            right.Location = new Point(331, 0);
            h1.Location = new Point(12, 0);
            h2.Location = new Point(46, 0); 
            h3.Location = new Point(80, 0);
            enemy.Location = new Point(-500, 50);
            player.Location = new Point(-500, 630);
            menu.Location = new Point(0,0);
            scoreB.Text = "0";
            move = 0;
            animating = false;
            moves = 4;
            speed = 10;
            dmg = false;
            dmg2 = false;
            namein.Location = new Point(-100, -100);
            startb = false;
            
            health = 3;
            immune = 2;
            immune2 = 2;
            score = 0;
            hover = false;
            random = 5;
            scoreB.Location = new Point(-100, -100);

            foreach (PictureBox p in bulletsf)
            {
                p.Dispose();

            }

            foreach (PictureBox p in bulletse)
            {
                p.Dispose();

            }

            HSB.Clear();
            HSB.AppendText("--HIGHSCORES--");
            HSB.AppendText("\r\n");

            for (int y = 0; y < 10; y++)
            {
                HSB.AppendText(names.ElementAt(y) + "-" + scores.ElementAt(y));
                HSB.AppendText("\r\n");
            }
            hover = false;
            startbut.Location = new Point(131, 243);
            HSB.Location = new Point(131, 380);

        }

        public void pause()
        {
            animating = false;
        }
        
        public SPACE_INVADERS()
        {
            path = System.Reflection.Assembly.GetExecutingAssembly().Location;
            path = Path.GetFullPath(Path.Combine(path, @"..\\..\\..\\"));
            Debug.WriteLine(path);
            InitializeComponent();
            try
            {
                bulle = new Bitmap(Path.Combine(path, @"SPRITES\bulle.png"));
                bullf = new Bitmap(Path.Combine(path, @"SPRITES\bullf.png"));
            }
            catch (ArgumentException)
            {
                Debug.WriteLine("Not found");
            }

            

            if (!File.Exists("scores.txt"))
            {
                
                
                FileStream fs = File.Create(Path.Combine(path, @"bin\\Debug\\scores.txt"));                           
                
                StreamWriter sw = new StreamWriter(fs);
               
                for (int i = 0; i < 10; i++)
                {
                sw.WriteLine("NULL,0");
                }
                
                sw.Close();
                fs.Close();
            }

            int x = 0;
            string[] lines = File.ReadAllLines("scores.txt");
            foreach (string line in lines)
            {


                String[] strlist = line.Split(separator, 2, StringSplitOptions.RemoveEmptyEntries);
               
                names.Add(strlist[0]);
                scores.Add(Convert.ToInt32(strlist[1]));

            }
            x = 0;
            foreach (string line in names)
            {
                Debug.WriteLine(line+"  "+ scores.ElementAt(x));
                x += 1;
            }
                


            shoot = new SoundPlayer(Path.Combine(path, @"SOUNDS\\shoot.wav"));

            left.Location = new Point(-1, 0);
            right.Location = new Point(331, 0);
            h1.Location = new Point(12, 0);
            h2.Location = new Point(46, 0);
            h3.Location = new Point(80, 0);
            enemy.Location = new Point(-500, 50);
            player.Location = new Point(-500, 630);

            for( x=0;x<10; x++)
            {
                HSB.AppendText(Environment.NewLine);
                HSB.AppendText(x+"yes-yes");

            }



        }
        

        private void SPACE_INVADERS_MouseMove(object sender, MouseEventArgs e)
        {
            if (animating)
            {
            if (e.Y > 500) { player.Location = new Point(e.X-25, e.Y-30); } else { player.Location = new Point(e.X-25, 500); }
            }
            


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (startb)
            {
            player.Refresh();
            enemy.Refresh();

            scoreB.Text = score.ToString();
            
            Refresh();
            }
           

        }

        

        private void SPACE_INVADERS_Load(object sender, EventArgs e)
        { Image img = enemy.Image;
            img.RotateFlip(RotateFlipType.Rotate180FlipNone);
            enemy.Image = img;
            end.Location = new Point(-200, -300);
            namein.Location = new Point(-200, 20);

            HSB.Clear();
            HSB.AppendText("--HIGHSCORES--");
            HSB.AppendText("\r\n");

            if( names.Count() == 0)
            { 
                for (int y = 0; y < 10; y++)
                {
                    names.Add("NULL");
                    scores.Add(0);
                }
            }
           
                for (int y = 0; y < 10; y++)
                {
                    HSB.AppendText(names.ElementAt(y) + "-" + scores.ElementAt(y));
                    HSB.AppendText("\r\n");
                }
           




        }


        private void playing_Tick(object sender, EventArgs e)
        {
            if (animating)
            {
            

            if (enemy.Location.X < 0)
            {
                move = 1;

            }
            else if(enemy.Location.X >440)
            {
                move = 0;
            }

            if (move == 1)
            {
                enemy.Location = new Point(enemy.Location.X+speed, enemy.Location.Y );
                
            }
            else
            {
                enemy.Location = new Point(enemy.Location.X-speed, enemy.Location.Y );
                
            }

            

            foreach(PictureBox p in bulletse)
                {
                    p.Location = new Point (p.Location.X , p.Location.Y+speed*2);
                    if (p.Location.Y > 800)
                    {
                        p.Dispose();
                        

                        


                    }

                    if (p.Bounds.IntersectsWith(player.Bounds) && dmg==false) {
                        Debug.WriteLine("hit");
                        
                        p.Dispose();
                            health-=1;
                        if (health == 2)
                        {
                            h3.Image = new Bitmap(Path.Combine(path, @"SPRITES\\hearte.png"));
                        }else if (health == 1)
                        {
                            h2.Image = new Bitmap(Path.Combine(path, @"SPRITES\\hearte.png"));

                        }else if(health == 0)
                        {
                            h1.Image=new Bitmap(Path.Combine(path, @"SPRITES\\hearte.png"));
                        }
                        dmg = true;
                        immune = 2;
                    }

                }

                foreach (PictureBox p in bulletsf)
                {
                    p.Location = new Point(p.Location.X, p.Location.Y -25);

                    if (p.Location.Y < 0)
                    {
                        p.Dispose();
                    }

                if (p.Bounds.IntersectsWith(enemy.Bounds) && dmg2 == false)
                {
                    Debug.WriteLine("hit");

                    p.Dispose();

                        score += 10;
                        Debug.WriteLine(score);
                        dmg2 = true;
                        immune2 = 1;
                    }
                }


                if (health == 0)
                {
                    animating = false;
                    startb = false;
                    end.Location = new Point(199, 369);
                    namein.Location = new Point(189, 343);

                }


            } 
            
        }

        private void second_Tick(object sender, EventArgs e)
        {
            int x;
            immune -= 1;
            immune2 -= 1;
            if (immune == 0)
            {
                dmg = false;
            }

            if (immune2 == 0)
            {
                dmg2 = false;
            }

            x = Convert.ToInt16(4 - speed / 10);
            if (x > 1)
            {
                x = Convert.ToInt16(4 - speed / 10);
            }
            else
            {
                x = 1;
            }
            if (animating == true)
            {
                if (moves != 0)
                {
                    moves -= 1;
                }
                else
                {
                    if (speed < 40)
                    {
                        speed = speed + 1;
                    }

                    moves = rnd.Next(1, x);
                    Debug.WriteLine(moves);

                    bullet(0);



                }

                random -= 1;

                if (random == 0)
                {
                    random = rnd.Next(2,4);
                    if (move == 0)
                    {
                        move = 1;
                    }
                    else
                    {
                        move = 0;
                    }
                }








            }
        }

        private void SPACE_INVADERS_Click(object sender, EventArgs e)
        {
            if (animating)
            {
            bullet(1);
            }
            
        }

        private void SPACE_INVADERS_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (startb == true)
            {
            if(e.KeyChar == ' ' )
            {
                if (animating == true)
                {
                    animating = false;
                }
                    else
                    {
                        animating = true;
                    }
                
            }
            }
           
        }

        private void startbut_MouseHover(object sender, EventArgs e)
        {

            var path2= "buttonh.png";
            if (hover)
            {
                path2 = "buttonp.png";
            }
            startbut.Image = new Bitmap(Path.Combine(path,@"SPRITES\\"+path2));


        }

        
        private void startbut_MouseLeave(object sender, EventArgs e)
        {
            startbut.Image = new Bitmap(Path.Combine(path, @"SPRITES\\button.png"));
            
        }

        

        private void startbut_MouseDown(object sender, MouseEventArgs e)
        {
            hover = true;
            startbut.Image = new Bitmap(Path.Combine(path, @"SPRITES\\buttonp.png"));
            
        }

       

        private void startbut_MouseUp(object sender, MouseEventArgs e)
        {
            Thread.Sleep(200);
            startbut.Location = new Point(-100, -100);
            HSB.Location = new Point(-200, -200);
            start();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void menu_Click(object sender, EventArgs e)
        {

        }

        private void end_MouseDown(object sender, MouseEventArgs e)
        {
            hover = true;
            end.Image = new Bitmap(Path.Combine(path, @"SPRITES\\buttonsp.png"));
        }

        private void end_MouseHover(object sender, EventArgs e)
        {
            var path2 = "buttonsh.png";
            if (hover)
            {
                path2 = "buttonsp.png";
            }
            end.Image = new Bitmap(Path.Combine(path, @"SPRITES\\" + path2));
        }

        private void end_MouseLeave(object sender, EventArgs e)
        {
            end.Image = new Bitmap(Path.Combine(path, @"SPRITES\\buttons.png"));
        }

        private void SPACE_INVADERS_FormClosing(object sender, FormClosingEventArgs e)
        {
            File.Delete("scores.txt");

            FileStream fs = File.Create(Path.Combine(path, @"bin\\Debug\\scores.txt"));

            StreamWriter sw = new StreamWriter(fs);

            for (int i = 0; i < 10; i++)
            {
                sw.WriteLine(names.ElementAt(i)+","+scores.ElementAt(i));
            }
            
            sw.Close();
            fs.Close();

        }

        private void end_Click(object sender, EventArgs e)
        {
            if (namein.Text == "ENTER NAME")
            {
                namein.Text = "UNKNOWN";
            }

            for(int i = 0; i < 10; i++)
            {
                if (scores.ElementAt(i) <= Convert.ToInt16(scoreB.Text))
                {
                    scores.Insert(i, Convert.ToInt16(scoreB.Text));
                    names.Insert(i, namein.Text);
                    for (int y = 0; y < 10; y++)
                    {
                        Debug.WriteLine(names.ElementAt(y) + "," + scores.ElementAt(y));
                    }
                    break;
                }
            }
            menustart();
        
        }

       
    }
}

